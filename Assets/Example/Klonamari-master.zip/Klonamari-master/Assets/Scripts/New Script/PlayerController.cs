﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {
	private Vector3 input = new Vector3();
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		input.Set(0, 0, 0);

		input.x = Input.GetAxis("Horizontal");

		input.z = Input.GetAxis("Vertical");

		input.Normalize();

		input.y = -Input.GetAxis("Rotate");

		
	}
}
