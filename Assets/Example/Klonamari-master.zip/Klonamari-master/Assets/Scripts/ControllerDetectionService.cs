﻿namespace Klonamari
{
    public interface ControllerDetectionService
    {
        void Init(float delay);

        void Tick(float deltaTime);
    }
}
