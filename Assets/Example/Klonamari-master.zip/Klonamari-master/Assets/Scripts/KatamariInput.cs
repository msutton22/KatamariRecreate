﻿using UnityEngine;

namespace Klonamari
{
    public interface KatamariInput
    {
        Vector3 Update(Katamari katamari);
    }
}
